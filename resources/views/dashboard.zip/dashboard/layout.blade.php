<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Yamaha Inventory</title>
    @vite('resources/css/app.css')
</head>
<body class="bg-gray-900 text-gray-200 min-h-screen flex">

    <!-- Sidebar -->
    <aside class="w-64 bg-gray-800 p-6 flex flex-col justify-between">
        <div>
            <h1 class="text-xl font-bold mb-10 flex items-center space-x-2">
                <span class="text-white">🛠️</span>
                <span>YAMAHA</span>
            </h1>

            <nav class="space-y-3">
                <a href="{{ route('dashboard.index') }}" class="flex items-center space-x-3 text-gray-300 hover:text-yellow-400">
                    <span>🏠</span> <span>Dashboard</span>
                </a>
                <a href="{{ route('dashboard.spareparts') }}" class="flex items-center space-x-3 text-gray-300 hover:text-yellow-400">
                    <span>⚙️</span> <span>Spare Parts</span>
                </a>
                <a href="{{ route('dashboard.notifications') }}" class="flex items-center space-x-3 text-gray-300 hover:text-yellow-400">
                    <span>🔔</span> <span>Notifications</span>
                </a>
                <a href="#" class="flex items-center space-x-3 text-gray-300 hover:text-yellow-400">
                    <span>📑</span> <span>Transactions</span>
                </a>
                <a href="#" class="flex items-center space-x-3 text-gray-300 hover:text-yellow-400">
                    <span>⚙️</span> <span>Settings</span>
                </a>
            </nav>
        </div>

        <div>
            <a href="{{ route('logout') }}" class="text-gray-400 hover:text-red-500">Logout</a>
        </div>
    </aside>

    <!-- Main Content -->
    <main class="flex-1 p-8">
        @yield('content')
    </main>

</body>
</html>
